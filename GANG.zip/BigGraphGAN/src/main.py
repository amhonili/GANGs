import numpy as np



val = []
gen = []
dis = []
genval = []
disval = []


def read_str_from_file(filename):
    with open(filename, "r") as f:
        lines = f.readlines()
        values = [line.split("\n") for line in lines]
    return values

def sep_gen_from_dis(values):
    gens = []
    diss = []
    for l in values:
        #print(l)
        if "gen:" in l[0]:
            #print("gen was here")
            gens.append(l)
        else:
            diss.append(l)
    return gens, diss

def take_values(values):
    valnum = []
    for a in values:
        valnum.append(float((a[0].split(":"))[1]))
    return valnum

print("starting...")

val = read_str_from_file("CA-GrQc.txt")

gen, dis = sep_gen_from_dis(val)

genval = take_values(gen)

disval = take_values(dis)
