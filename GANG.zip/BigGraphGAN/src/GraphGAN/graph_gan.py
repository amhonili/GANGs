import os
import collections
import tqdm
import multiprocessing
import pickle
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import config
import generator
import discriminator
import utils
import link_prediction as lp
import networkx as nx

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
accuracymeasure = []
precisionmeasure = []


class GraphGAN(object):
    def __init__(self, n_emb_g, n_emb_d):
        print("reading graphs...")

        print("reading initial embeddings...")

        self.graph = nx.Graph()
        #self.init_graph([20, 20, 20, 20, 20], [[0.9, 0.04, 0.04, 0.04, 0.04], [0.04, 0.9, 0.04, 0.04, 0.04],
        #[0.04,0.04,0.9, 0.04, 0.04], [0.04,0.04,0.04,0.9,0.04], [0.04,0.04,0.04,0.04,0.9]], n_emb)
    #    self.init_graph([20,20,20, 20, 20],[[0.9,0.1,0.1, 0.1, 0.1], [0.1,0.9,0.1, 0.1, 0.1], [0.1,0.1,0.9, 0.1, 0.1],
    #    [0.1, 0.1, 0.1, 0.9, 0.1], [0.1, 0.1, 0.1, 0.1, 0.9]], n_emb)
        self.communities = [20,20,20]
        self.init_graph(self.communities,[[0.7,0.4,0.4],[0.4,0.7,0.4],[0.4,0.4,0.7]], n_emb_g, n_emb_d)
        #utils.betweenness_centrality(self.graph)
        #utils.degree_distribution(self.graph)
        #utils.cluster_coeffs(self.graph)
        self.center_nodes = None
        self.finalgraph = None
        self.distance = []
        self.disposvalues = []
        self.disnegvalues = []
        self.loss1 = []
        self.loss2 = []
        self.loss3 = []
        self.node1 = []
        self.node2 = []
        self.gen1 = []
        self.gen2 = []
        self.gen3 = []
        self.gen4 = []
        self.dis1 = []
        self.dis2 = []
        self.dis3 = []
        self.dis4 = []
        self.gengradvals = []
        self.disgradvals = []
        self.gengrad = []
        self.number_of_edges = 0
        self.accuracy = 0
        self.recall = 0
        self.precision = 0
        self.labels = []
        self.finallabel = []
        self.problabel = []
        self.generatorloss = []
        self.discriminatorloss = []
        self.adjmatrix = []
        self.finaladjmatrix = []
        self.fprobabilistic_d = []
        self.fprobabilistic_g = []


        if(config.mode == "link_prediction"):
            self.n_node, self.graph = utils.read_edges(config.train_filename, config.test_filename)

        elif(config.mode == "edgelist"):
            self.n_node, self.graph = utils.read_total_edges(config.observe_filename)
            self.root_nodes = [i for i in range(self.n_node)]
            self.node1, self.node2, self.labels = self.prepare_data()

        elif(config.mode == "adjacency"):
            print("Real Graph...")
            #utils.draw_graph(self.graph)
            #initcc, initdense, initavgdg = utils.graph_metrics(self.graph)
            #print("average initial Clustering Coeff is ", initcc)
            #print("average initial Density is ", initdense)
            #print("average initial Degree is ", initavgdg)
            #nx.draw_circular(self.graph, with_labels = True)
            #plt.show()
            self.adjmatrix = utils.graph_to_array(self.graph)
            density = utils.community_density(self.adjmatrix, self.communities)
            print("initial density is.. ",density)
            self.n_node = len(self.adjmatrix)
            self.node1, self.node2, self.labels = self.prepare_edges()
            self.number_of_edges = np.count_nonzero(self.labels)
            #print("total edges ",self.number_of_edges)

        """
        if os.path.isfile(config.cache_filename):
            print("reading all edges from cache...")
            pickle_file = open(config.cache_filename, 'rb')
            self.center_nodes, self.labels = pickle.load(pickle_file)
            pickle_file.close()
        else:
            print("constructing all edges...")
            pickle_file = open(config.cache_filename, 'wb')
            self.center_nodes, self.labels = self.prepare_data()
            #pickle.dump(self.center_nodes, self.labels, pickle_file)
            pickle.dump(self.trees, pickle_file)
            pickle_file.close()
"""
        #print("building GAN model...")
        self.discriminator = None
        self.generator = None
        self.build_generator(n_emb_g)
        self.build_discriminator(n_emb_d)
        #print("Gan's initialized ")
        self.latest_checkpoint = tf.train.latest_checkpoint(config.model_log)
        self.saver = tf.train.Saver()

        self.config = tf.ConfigProto()
        self.config.gpu_options.allow_growth = True
        self.init_op = tf.group(tf.global_variables_initializer(), tf.local_variables_initializer())
        self.sess = tf.Session(config=self.config)
        self.sess.run(self.init_op)

    def build_generator(self, n):
        """initializing the generator"""

        with tf.variable_scope("generator"+str(n)):
            self.generator = generator.Generator(n_node = self.n_node, node_emd_init = self.node_embed_init_g,
             i=n)

    def build_discriminator(self, n):
        """initializing the discriminator"""

        with tf.variable_scope("discriminator"+str(n)):
            self.discriminator = discriminator.Discriminator(n_node = self.n_node, node_emd_init = self.node_embed_init_d,
            i=n)

    def train(self, n_emb_g, n_emb_d):
        # restore the model from the latest checkpoint if exists
        checkpoint = tf.train.get_checkpoint_state(config.model_log)
        if checkpoint and checkpoint.model_checkpoint_path and config.load_model:
            print("loading the checkpoint: %s" % checkpoint.model_checkpoint_path)
            self.saver.restore(self.sess, checkpoint.model_checkpoint_path)

        self.write_embeddings_to_file(n_emb_g, n_emb_d)
        print("start training...")
        for epoch in range(config.n_epochs):
            #print("epoch ",epoch)
            if epoch > 0 and epoch % config.save_steps == 0:
                self.saver.save(self.sess, config.model_log + "model.checkpoint")

            genvalue, disvalue = self.prepare_constants(self.node1, self.node2)

            for d_epoch in range(config.n_epochs_dis):
                #train_size = len(self.node1)
                #start_list = list(range(0, train_size, 10))
                #np.random.shuffle(start_list)
                #for start in start_list:
                    #end = start + 10
                self.sess.run(self.discriminator.d_updates,
                                  feed_dict= {self.discriminator.node_id: np.array(self.node1),
                                             self.discriminator.node_neighbor_id: np.array(self.node2),
                                             self.discriminator.label: np.array(self.labels),
                                             self.discriminator.gen: np.array(genvalue)})

            # Generator's training steps
            for g_epoch in range(config.n_epochs_gen):

                #for start in start_list:
                    #end = start + 10
                self.sess.run(self.generator.g_updates,
                                  feed_dict = {self.generator.node_id: np.array(self.node1),
                                              self.generator.node_neighbor_id: np.array(self.node2),
                                              self.generator.label: np.array(self.labels),
                                              self.generator.dis: np.array(disvalue)})

            self.write_embeddings_to_file(n_emb_g, n_emb_d)
            self.loss_values(disvalue, genvalue)
        print("training completes")
        self.write_embeddings_to_file(n_emb_g, n_emb_d)

        self.fprobabilistic_g, self.fprobabilistic_d = self.final_prob(n_emb_g, n_emb_d)
        self.finaladjmatrix = np.array(utils.graph_generator(self.fprobabilistic_g))
        #adjdismatrix = np.array(utils.graph_generator(self.fprobabilistic_d))
        self.finalgraph = utils.array_to_graph(self.finaladjmatrix)
        print("final graph...")
        #graphd = utils.array_to_graph(adjdismatrix)
        #utils.betweenness_centrality(self.finalgraph)
        #utils.degree_distribution(self.finalgraph)
        utils.draw_graph(self.finalgraph)
        #nx.draw_circular(self.finalgraph, with_labels = True)
        #plt.show()
        #utils.cluster_coeffs(self.finalgraph)
        self.lossplot()

        density = utils.community_density(self.finaladjmatrix, self.communities)
        #densitydis = utils.community_density(adjdismatrix, [20,20,20, 20, 20])
        print("generator's density is.. ",density)
        #print("discriminator's density is.. ",densitydis)
        self.finallabel = utils.edge_detector(self.finaladjmatrix)
        self.problabel = utils.edge_detector(self.fprobabilistic_g)
        #problabeld =  utils.edge_detector(self.fprobabilistic_d)
        self.accuracy, self.precision, _ = utils.metrics(self.labels, self.problabel)
        #accuracymeasure.append((n_emb, self.accuracy))
        #acc, prec = utils.metrics(self.labels, problabeld)
        print("gen's precision is ", self.precision)
        print("gen's accuracy is ", self.accuracy)
        initcc, initdense, initavgdg = utils.graph_metrics(self.finalgraph)
        print("average final Clustering Coeff is ", initcc)
        print("average final Density is ", initdense)
        print("average final Degree is ", initavgdg)

        #print("dis' accuracy is ", acc)
        #print("dis's precision is ", prec)
        #print("generator's recall is ", rec)

    def final_prob(self, n_emb_g, n_emb_d):
        final_embed_d = utils.embedding_matrix(config.emb_filenames[1], self.n_node, n_emb_d)
        final_embed_g = utils.embedding_matrix(config.emb_filenames[0], self.n_node, n_emb_g)
        prob_matrix_d = utils.probabilistic_matrix(final_embed_d)
        prob_matrix_g = utils.probabilistic_matrix(final_embed_g)
        return prob_matrix_g, prob_matrix_d

    def lossplot(self):
        plt.plot(self.generatorloss, label ='generator\'s loss function', color = '#2c7fb8')
        plt.plot(self.discriminatorloss, label = 'discriminator\'s loss function', color = '#7fcdbb')
        plt.xlabel("number of epochs")
        plt.ylabel("Loss Function")
        plt.title("Learning Curve")
        plt.legend()
        plt.show()
        plt.plot(self.distance)
        plt.xlabel("epochs")
        plt.title("distance between real and fake graph")
        plt.show()
        plt.plot(self.disposvalues, label = 'dis pos val',color = 'r')
        plt.plot(self.disnegvalues, label = 'dis neg val', color = 'b')
        plt.title("discriminator values")
        plt.legend()
        plt.show()
        plt.plot(self.loss1, label = 'firstTerm', color = 'r')
        plt.plot(self.loss2, label = 'secondTerm', color = 'b')
        plt.legend()
        plt.show()
        plt.plot(self.gengradvals)
        plt.title("gradient value of generator")
        plt.show()

    def init_graph(self, communities, probabilities, n_emb_g, n_emb_d):
        self.graph = utils.build_sbm(communities, probabilities)
        totalnodes = sum(communities)
        #self.graph = nx.karate_club_graph()
        #totalnodes = nx.number_of_nodes(self.graph)
        self.node_embed_init_g = utils.store_embedding(utils.graph_to_array(self.graph), totalnodes, n_emb_g)
        prob_matrix_g = utils.probabilistic_matrix(self.node_embed_init_g)
        gengraph = utils.array_to_graph(np.array(utils.graph_generator(prob_matrix_g)))
        utils.draw_graph(gengraph)
        genmatrix = utils.graph_to_array(gengraph)
        gendense = utils.community_density(genmatrix, self.communities)
        print("initial embedding density is: ")
        print(gendense)
        self.node_embed_init_d = utils.store_embedding(genmatrix, totalnodes, n_emb_d)
        prob_matrix_d = utils.probabilistic_matrix(self.node_embed_init_d)
        disgraph = utils.array_to_graph(np.array(utils.graph_generator(prob_matrix_d)))
        utils.draw_graph(disgraph)

    def posnegcounter(self,A):
        pos = 0
        neg = 0
        zero = 0
        for a in A:
            if(a > 0):
                pos += 1
            if(a < 0):
                neg += 1
            else:
                zero += 1

        return pos, neg, zero

    def loss_values(self, discons, gencons):
        '''
        returns the current loss values of the generator and discriminators
        '''
        dist = self.sess.run(self.discriminator.distance,
                                            feed_dict = {self.discriminator.node_id: np.array(self.node1),
                                            self.discriminator.node_neighbor_id: np.array(self.node2),
                                            self.discriminator.label: np.array(self.labels),
                                            self.discriminator.gen: np.array(gencons)})
        self.distance.append(dist)
        diszvpos = self.sess.run(self.discriminator.disvpos,
                                    feed_dict = {self.discriminator.node_id: np.array(self.node1),
                                    self.discriminator.node_neighbor_id: np.array(self.node2),
                                    self.discriminator.label: np.array(self.labels),
                                    self.discriminator.gen: np.array(gencons)})
        self.disposvalues.append(diszvpos)
        diszvneg = self.sess.run(self.discriminator.disvneg,
                                    feed_dict = {self.discriminator.node_id: np.array(self.node1),
                                    self.discriminator.node_neighbor_id: np.array(self.node2),
                                    self.discriminator.label: np.array(self.labels),
                                    self.discriminator.gen: np.array(gencons)})
        self.disnegvalues.append(diszvneg)
        loss1 = self.sess.run(self.generator.loss1,
                                    feed_dict = {self.generator.node_id: np.array(self.node1),
                                    self.generator.node_neighbor_id: np.array(self.node2),
                                    self.generator.label: np.array(self.labels),
                                    self.generator.dis: np.array(discons)})
        self.loss1.append(loss1)
        loss2 = self.sess.run(self.generator.loss2,
                                    feed_dict = {self.generator.node_id: np.array(self.node1),
                                    self.generator.node_neighbor_id: np.array(self.node2),
                                    self.generator.label: np.array(self.labels),
                                    self.generator.dis: np.array(discons)})
        self.loss2.append(loss2)

        genzloss = self.sess.run(self.generator.loss,
                                    feed_dict = {self.generator.node_id: np.array(self.node1),
                                    self.generator.node_neighbor_id: np.array(self.node2),
                                    self.generator.label: np.array(self.labels),
                                    self.generator.dis: np.array(discons)})
        self.generatorloss.append(genzloss)
        gengrad = self.sess.run(self.generator.grad,
                                    feed_dict = {self.generator.node_id: np.array(self.node1),
                                    self.generator.node_neighbor_id: np.array(self.node2),
                                    self.generator.label: np.array(self.labels),
                                    self.generator.dis: np.array(discons)})
#
#
        for g, _ in gengrad:
            self.gengradvals.append(utils.grad_norm(g[0]))


        diszloss = self.sess.run(self.discriminator.loss,
                                    feed_dict = {self.discriminator.node_id: np.array(self.node1),
                                    self.discriminator.node_neighbor_id: np.array(self.node2),
                                    self.discriminator.label: np.array(self.labels),
                                    self.discriminator.gen: np.array(gencons)})
        self.discriminatorloss.append(diszloss)


    def prepare_constants(self,node1,node2):
        '''
        This function returns the <g_i,g_j> and <d_i, d_j> values
        '''
        n = len(node1)
        genzscore = self.sess.run(self.generator.score,
                                   feed_dict={self.generator.node_id: np.array(node1),
                                     self.generator.node_neighbor_id: np.array(node2)})

        diszscore = self.sess.run(self.discriminator.score,
                                    feed_dict={self.discriminator.node_id: np.array(node1),
                                    self.discriminator.node_neighbor_id: np.array(node2)})

        return genzscore, diszscore


    def prepare_edges(self):
        """
        Generate pairs of nodes that are from the real edge set and nodes that
        are not from that set. E_r and E_r'
        """
        labels = []
        node1 = []
        node2 = []
        n = len(self.adjmatrix)
        for i in range(n):
            for j in range(i+1, n):
                node1.append(i)
                node2.append(j)
                if self.adjmatrix[i][j] == 1:
                    labels.append(1)
                else:
                    labels.append(0)
        return node1, node2, labels


    def prepare_data(self):
        """
        Generate pairs of nodes that are from the real edge set and nodes that
        are not from that set. E_r and E_r'
        """
        labels = []
        edges = []
        totaledges = []
        node1 = []
        node2 = []
        edges = utils.read_edges_from_file(config.observe_filename)
        for i in range(self.n_node):
            for j in range(i+1, self.n_node):
                node1.append(i)
                node2.append(j)
                if [i,j] in edges:
                    labels.append(1)
                else:
                    labels.append(0)
        return node1, node2, labels

    def write_embeddings_to_file(self, n_emb_g, n_emb_d):
        """write embeddings of the generator and the discriminator to files"""

        modes = [self.generator, self.discriminator]

        embedding_matrix = self.sess.run(modes[0].embedding_matrix)
        index = np.array(range(self.n_node)).reshape(-1, 1)
        embedding_matrix = np.hstack([index, embedding_matrix])
        embedding_list = embedding_matrix.tolist()
        embedding_str = [str(int(emb[0])) + "\t" + "\t".join([str(x) for x in emb[1:]]) + "\n"
                         for emb in embedding_list]
        with open(config.emb_filenames[0], "w+") as f:
            lines = [str(self.n_node) + "\t" + str(n_emb_g) + "\n"] + embedding_str
            f.writelines(lines)

        embedding_matrix = self.sess.run(modes[1].embedding_matrix)
        index = np.array(range(self.n_node)).reshape(-1, 1)
        embedding_matrix = np.hstack([index, embedding_matrix])
        embedding_list = embedding_matrix.tolist()
        embedding_str = [str(int(emb[0])) + "\t" + "\t".join([str(x) for x in emb[1:]]) + "\n"
                         for emb in embedding_list]
        with open(config.emb_filenames[1], "w+") as f:
            lines = [str(self.n_node) + "\t" + str(n_emb_d) + "\n"] + embedding_str
            f.writelines(lines)


    @staticmethod
    def evaluation(self):
        results = []
        if config.app == "link_prediction":
            for i in range(2):
                lpe = lp.LinkPredictEval(
                    config.emb_filenames[i], config.test_filename, config.test_neg_filename, self.n_node, config.n_emb_g)
                result = lpe.eval_link_prediction()
                results.append(config.modes[i] + ":" + str(result) + "\n")

        with open(config.result_filename, mode="a+") as f:
            f.writelines(results)


if __name__ == "__main__":
    #for i in range(1, 31):
        #print("test number ", i)
    graph_gan = GraphGAN(4, 4)
    graph_gan.train(4, 4)
    #utils.sensitivity_analysis(accuracymeasure, "embedding\'s dimension", "SBM3")
    #print(accuracymeasure)
