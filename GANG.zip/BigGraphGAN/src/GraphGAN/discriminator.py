import tensorflow as tf
import config
import utils

class Discriminator(object):
    #tf.reset_default_graph()
    def __init__(self, n_node, node_emd_init, i):

        self.n_node = n_node
        self.node_emd_init = node_emd_init

        with tf.variable_scope('discriminator'+str(i)):
            self.embedding_matrix = tf.get_variable(name = "Discriminators_embedding",
                                                    shape = self.node_emd_init.shape,
                                                    initializer = tf.constant_initializer(self.node_emd_init),
                                                    trainable = True)
        #    self.bias_vector = tf.Variable(tf.zeros([self.n_node]))

        self.node_id = tf.placeholder(tf.int32, shape = [None])
        self.node_neighbor_id = tf.placeholder(tf.int32, shape = [None])
        self.label = tf.placeholder(tf.float32, shape= [None])
        self.gen = tf.placeholder(tf.float32, shape= [None] )

        self.node_embedding = tf.nn.embedding_lookup(self.embedding_matrix, self.node_id)
        self.node_neighbor_embedding = tf.nn.embedding_lookup(self.embedding_matrix, self.node_neighbor_id)
        #self.bias = tf.gather(self.bias_vector, self.node_neighbor_id)
        self.score = tf.reduce_sum(tf.multiply(self.node_embedding, self.node_neighbor_embedding), axis=1) #+ self.bias

    #    self.score = tf.clip_by_value(self.score, -10, 10)
        l = 1
        G = tf.sigmoid(self.gen)
        D = tf.sigmoid(self.score)
        firstTerm = (1-G)*(D)*(self.label)
        secondTerm = l*G*(D)*(1-self.label)
        thirdTerm = G*(1-D)*(self.label)
        fourthTerm = (1-G)*(1-D)*(1-self.label)

        self.loss = - tf.reduce_sum(((firstTerm) + (secondTerm)))

        self.disvpos = tf.reduce_sum((self.score)*(self.label))
        self.disvneg = tf.reduce_sum((self.score)*(1 - self.label))
        self.distance = tf.reduce_sum((1 - G)*(self.label) + (G)*(1-self.label))

        optimizer = tf.train.AdamOptimizer(config.lr_dis)
        self.grad = optimizer.compute_gradients(self.loss)
        self.d_updates = optimizer.minimize(self.loss)
