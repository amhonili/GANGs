import utils
import config


def visualization(dimensions):
    final_embed = utils.embedding_matrix(config.emb_filenames[0], dimensions, config.n_emb)
    prob_matrix = utils.probabilistic_matrix(final_embed)
    final_graph = utils.graph_generator(prob_matrix)
    print(final_graph)
visualization(10)
