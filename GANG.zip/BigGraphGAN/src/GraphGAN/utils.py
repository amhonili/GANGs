import collections
import numpy as np
import tensorflow as tf
import networkx as nx
from networkx.algorithms import community as comm
import matplotlib.pyplot as plt
import sklearn.manifold as skm

def str_list_to_float(str_list):
    return [float(item) for item in str_list]


def str_list_to_int(str_list):
    return [int(item) for item in str_list]

def read_total_edges(filename):
    graph = {}
    nodes = set()
    total_edges = read_edges_from_file(filename)

    for edge in total_edges:
        nodes.add(edge[0])
        nodes.add(edge[1])
        if graph.get(edge[0]) is None:
            graph[edge[0]] = []
        if graph.get(edge[1]) is None:
            graph[edge[1]] = []
        graph[edge[0]].append(edge[1])
        graph[edge[1]].append(edge[0])

    return len(nodes), graph

def edge_detector(matrix):
    label = []
    n = len(matrix)
    for i in range(n):
        for j in range(i+1,n):
            label.append(matrix[i][j])

    return label

def sensitivity_analysis(metric, name, dataset):
    #lists = sorted(metric.items())
    X, Y = zip(*metric)
    #plt.xlabel(name)
    minY = round(np.min(Y), 2)
    maxY = round(np.max(Y), 2)
    minX = round(np.min(X), 2)
    maxX = round(np.max(X), 2)
    stepY = round((maxY - minY)/10, 2)
    stepX = round((maxX - minX)/10, 2)
    plt.xlim((0,maxX + stepX))
    plt.ylim((minY, maxY + stepY))
    plt.xticks((np.arange(minX, maxX, step = stepX)))
    plt.yticks((np.arange(minY, maxY, step = stepY)))
    plt.ylabel("Average Accuracy", fontsize = 13)
    #plt.title(dataset)
    plt.plot(X, Y, color = 'r')
    plt.show()

def cluster_coeffs(g):
    node_coeffs = {}
    node_coeffs = nx.clustering(g)
    nodes = sorted(node_coeffs.items())
    node, coeffs = zip(*nodes)
    plt.xlabel("node")
    plt.ylim(np.min(coeffs), np.max(coeffs) + 0.04)
    plt.title("Clustering Coefficient")
    plt.bar(node, coeffs, color = 'r')
    plt.show()

def community_density(matrix, community):
    community = np.array(community)
    n = len(community)
    density = np.zeros((n,n))
    complete_edge = np.zeros((n,n))
    total_edges_in_community = community*(community-1)/2
    previ = 0
    for i in range(n):
        prevj = 0
        for j in range(n):
            if(i == j):
                complete_edge[i][j] = total_edges_in_community[i]
            else:
                complete_edge[i][j] = community[i]*community[j]/2

            m = np.count_nonzero(matrix[previ: previ + community[i],prevj:prevj + community[j]])
            density[i][j] = m/(2*complete_edge[i][j])

            prevj = prevj + community[j]
        previ = previ + community[i]
    #print(complete_edge)
    return density

def read_edges(train_filename, test_filename):
    """read data from files

    Args:
        train_filename: training file name
        test_filename: test file name

    Returns:
        node_num: int, number of nodes in the graph
        graph: dict, node_id -> list of the nodes' neighbours
    """

    graph = {}
    nodes = set()
    train_edges = read_edges_from_file(train_filename)
    test_edges = read_edges_from_file(test_filename) if test_filename != "" else []

    for edge in train_edges:
        nodes.add(edge[0])
        nodes.add(edge[1])
        if graph.get(edge[0]) is None:
            graph[edge[0]] = []
        if graph.get(edge[1]) is None:
            graph[edge[1]] = []
        graph[edge[0]].append(edge[1])
        graph[edge[1]].append(edge[0])

    for edge in test_edges:
        nodes.add(edge[0])
        nodes.add(edge[1])
        if graph.get(edge[0]) is None:
            graph[edge[0]] = []
        if graph.get(edge[1]) is None:
            graph[edge[1]] = []

    return len(nodes), graph


def read_edges_from_file(filename):
    with open(filename, "r") as f:
        lines = f.readlines()
        edges = [str_list_to_int(line.split()) for line in lines]
    return edges


def read_embeddings(filename, n_node, n_embed):
    """read pretrained node embeddings
    """

    with open(filename, "r") as f:
        lines = f.readlines()[1:]  # skip the first line
        embedding_matrix = np.random.rand(n_node, n_embed)
        for line in lines:
            emd = line.split()
            embedding_matrix[int(emd[0]), :] = str_list_to_float(emd[1:])
        return embedding_matrix

def probabilistic_matrix(embedding):
    probmatrix = []
    probmatrix = np.matmul(embedding, embedding.transpose())
    #print("before sigmoid")
    probmatrix = sig(probmatrix)
    dprime = (np.triu(probmatrix)).sum()
    print("dprime is ", dprime)
    #print(probmatrix)
    #probmatrix =  probmatrix * d/dprime
    #probmatrix = np.clip(probmatrix, 0, 1)
    return probmatrix

def embedding_matrix(filename, n_node, n_embed):

    with open(filename, "r") as f:
        lines = f.readlines()[1:]
        embed = np.zeros((n_node, n_embed))
        for line in lines:
            emd = line.split()
            embed[int(emd[0]), :] = str_list_to_float(emd[1:])
        return embed

def store_embedding(adj, n_node, dimension):
    """creates a uniformly distributed embedding between (-1.5, +1.5)"""
    #embedding_matrix = np.random.normal(loc = 0, scale = 1,size = (n_node, dimension))
    #embedding_matrix = 2*np.random.rand(n_node, dimension)
    #embedding_matrix = embedding_matrix - 1
    #embedding_matrix = np.zeros((n_node, dimension))
    #embedding_dict = nx.spectral_layout(g, dim = dimension)
    #print(embedding_dict)
    #for i in range (0, n_node):
    #    embedding_matrix[i] = embedding_dict[i]
    embedding_matrix = skm.spectral_embedding(adj, n_components = dimension)
    return embedding_matrix

def grad_norm(x):
    return np.linalg.norm(x)

def reindex_node_id(edges):
    """reindex the original node ID to [0, node_num)

    Args:
        edges: list, element is also a list like [node_id_1, node_id_2]
    Returns:
        new_edges: list[[1,2],[2,3]]
        new_nodes: list [1,2,3]
    """

    node_set = set()
    for edge in edges:
        node_set = node_set.union(set(edge))

    node_set = list(node_set)
    new_nodes = set()
    new_edges = []
    for edge in edges:
        new_edges.append([node_set.index(edge[0]), node_set.index(edge[1])])
        new_nodes = new_nodes.add(node_set.index(edge[0]))
        new_nodes = new_nodes.add(node_set.index(edge[1]))

    new_nodes = list(new_nodes)
    return new_edges, new_nodes


def generate_neg_links(train_filename, test_filename, test_neg_filename):
    """
    generate neg links for link prediction evaluation
    Args:
        train_filename: the training edges
        test_filename: the test edges
        test_neg_filename: the negative edges for test
    """

    train_edges = read_edges_from_file(train_filename)
    test_edges = read_edges_from_file(test_filename)
    neighbors = {}  # dict, node_ID -> list_of_neighbors
    for edge in train_edges + test_edges:
        if neighbors.get(edge[0]) is None:
            neighbors[edge[0]] = []
        if neighbors.get(edge[1]) is None:
            neighbors[edge[1]] = []
        neighbors[edge[0]].append(edge[1])
        neighbors[edge[1]].append(edge[0])
    nodes = set([x for x in range(len(neighbors))])

    # for each edge in the test set, sample a negative edge
    neg_edges = []

    for i in range(len(test_edges)):
        edge = test_edges[i]
        start_node = edge[0]
        neg_nodes = list(nodes.difference(set(neighbors[edge[0]] + [edge[0]])))
        neg_node = np.random.choice(neg_nodes, size=1)[0]
        neg_edges.append([start_node, neg_node])
    neg_edges_str = [str(x[0]) + "\t" + str(x[1]) + "\n" for x in neg_edges]
    with open(test_neg_filename, "w+") as f:
        f.writelines(neg_edges_str)

def build_sbm(sizes, probs):
    g = nx.stochastic_block_model(sizes, probs, seed=0)
    return g

def draw_graph(g):
    nx.draw_networkx(g)
    plt.axis('off')
    plt.show()

def graph_to_array(g):
    A = nx.to_numpy_array(g)
    return A

def array_to_graph(arr):
    G = nx.from_numpy_array(arr)
    return G

def degree_distribution(g):
    totalnodes = nx.number_of_nodes(g)
    degreeSeq = sorted([d for n, d in g.degree()], reverse=True)  # degree sequence
    degreeCount = collections.Counter(degreeSeq)
    deg, cnt = zip(*degreeCount.items())
    cnt = np.array(cnt)
    cnt = cnt/totalnodes
    step = round(np.max(cnt)/10, 2)
    plt.title("Degree Distribution")
    plt.ylabel("fraction of nodes")
    plt.xlabel("Degree")
    plt.yticks(np.arange(0, np.max(cnt) + step, step ))
    plt.bar(deg, cnt, color='r')
    plt.show()

def betweenness_centrality(g):
    bc = {}
    bc = nx.betweenness_centrality(g)
    listbc = sorted(bc.items())
    x, y = zip(*listbc)
    plt.xlabel("Vertex")
    plt.ylabel("BC")
    plt.title("Betweenness Centrality")
    plt.xticks(np.arange(0,100, step = 5))
    #plt.yticks(np.arange(0,0.03, step = 0.002))
    plt.bar(x, y, color = 'r')
    plt.show()

def graph_metrics(g):
    avgcc = nx.average_clustering(g)
    density = nx.density(g)
    avgdg = nx.number_of_edges(g)/nx.number_of_nodes(g)

    return avgcc, density, avgdg

def graph_generator(probmatrix):
    n = len(probmatrix)
    matrix = np.zeros((n, n))
    for i in range(n):
        matrix[i][i] = 0
        for j in range(i+1, n):
            prob = probmatrix[i][j]
            matrix[i][j] = np.random.choice([1,0], 1,
            p = [prob, 1-prob])[0]
            matrix[j][i] = matrix[i][j]
    print("number of final edges from adjmatrix",np.count_nonzero(np.triu(matrix)))
    return matrix

def metrics(initial_edge, final_prob_edge):
    initlabel = np.array(initial_edge)
    finallabel = np.array(final_prob_edge)
    n = len(finallabel)

    tp = 0
    fn = 0
    fp = 0
    tn = 0
    edgecnt = 0
    for e in range(n):
        i = initlabel[e]
        f = finallabel[e]
        if(i == 1):
            edgecnt += 1
            tp = tp + f
            fn = fn + (1 - f)
        else:
            fp = fp + f
            tn = tn + (1 - f)
    print("true positive is ",tp/edgecnt)
    print("true negative is ", tn/(n-edgecnt))
    print("False positive is ", fp/edgecnt)
    print("False negative is ", fn/(n-edgecnt))
    accuracy = (tp + tn)/n
    precision = tp/(tp + fp)
    tpr = tp/(tp+fn)
    fpr = fp/(fp+tn)
    roc = tpr/fpr

    return accuracy, precision, roc

def sig(x):
    sigx = (1/(1 + np.exp(-x/1)))
    return sigx

def logprob(x):
    logprob = tf.log(1+tf.exp(-x))
    return logprob
