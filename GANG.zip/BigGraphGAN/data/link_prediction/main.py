from random import choice

graph = {}
v_set = set()
v_list = []
sd = {}


def read(file):
    reader = open(file)
    for line in reader:
        arr = line.strip().split('\t')
        v1 = int(arr[0])
        v2 = int(arr[1])
        if v1 not in graph:
            graph[v1] = set()
        if v2 not in graph:
            graph[v2] = set()
        graph[v1].add(v2)
        graph[v2].add(v1)
        v_set.add(v1)
        v_set.add(v2)


def initialize():
    for i in graph.keys():
        sd[i] = {}
        for j in graph.keys():
            sd[i][j] = -2


def bfs_on_original_graph(v1):
    added = {}
    for j in graph.keys():
        sd[v1][j] = -1
        added[j] = False
    queue = [v1]
    added[v1] = True
    sd[v1][v1] = 0
    p = 0
    q = 1
    while p != q:
        cur = queue[p]
        for v in graph[cur]:
            if not added[v]:
                queue.append(v)
                added[v] = True
                sd[v1][v] = sd[v1][cur] + 1
                q += 1
        p += 1


def bfs_on_reduced_graph(v1, v2):
    added = {}
    dist = {}
    for key in graph.keys():
        added[key] = False
        dist[key] = -1
    queue = [v1]
    added[v1] = True
    dist[v1] = 0
    p = 0
    q = 1
    while p != q:
        cur = queue[p]
        for v in graph[cur]:
            if not added[v]:
                queue.append(v)
                added[v] = True
                dist[v] = dist[cur] + 1
                q += 1
            if v == v2:
                return dist[v2]
        p += 1
    return dist[v2]


def shortest_distance(v1, v2):
    if v2 in graph[v1]:
        graph[v1].remove(v2)
        graph[v2].remove(v1)
        dis = bfs_on_reduced_graph(v1, v2)
        graph[v1].add(v2)
        graph[v2].add(v1)
    elif sd[v1][v2] != -2:
        dis = sd[v1][v2]
    elif sd[v2][v1] != -2:
        dis = sd[v2][v1]
    else:
        bfs_on_original_graph(v1)
        dis = sd[v1][v2]
    return dis


res = {}
res['p'] = {}
res['n'] = {}

print('reading...')
read('CA-GrQc.txt')
print('initializing...')
initialize()
v_list = list(v_set)
print('initialization complete')
cnt = 0
for i in range(1000000):
    if cnt % 1000 == 0:
        print(cnt)
    cnt += 1
    v1 = choice(v_list)
    v2 = choice(v_list)
    if v1 == v2:
        continue
    dist = shortest_distance(v1, v2)
    if v2 in graph[v1]:
        if dist in res['p']:
            res['p'][dist] += 1
        else:
            res['p'][dist] = 1
    else:
        if dist in res['n']:
            res['n'][dist] += 1
        else:
            res['n'][dist] = 1
print(res)

